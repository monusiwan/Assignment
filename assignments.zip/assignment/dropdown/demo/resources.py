from import_export import resources
from .models import *

class AddItemsResource(resources.ModelResource):
    class Meta:
        model = AddItems
        unique_together = ('Name')