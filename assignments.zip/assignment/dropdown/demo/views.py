from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import *
from .models import *
from .resources import *
from django.contrib import messages
from tablib import Dataset
from django.core.files import File
# -----------------Home------------------------
# Base url: 127.0.0.1:8000

def Home(request):
    return render(request,'home.html')


# ----------------------Dropdown----------------------
# Base Url: 127.0.0.1:8000/dropdown/

def HomeView(request):
    d={}
    if request.method=='GET':
        form = InsertItemsForm()
        show = InsertItems.objects.all()
        d={'fm':form,'show':show}
        return render(request, "dropdown.html",context=d)
    elif(request.method=="POST"):
        form = InsertItemsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dropdown')
        else:
            return HttpResponse("Declined")

    else:
        d={'fm':form}
        return render(request, "dropdown.html",context=d)



# ---------------Assignment 2---------------------------
# Base Url: 127.0.0.1:8000/upload/

def excelsheet_upload(request):
    if request.method=='POST':
        add_items= AddItemsResource()
        dataset = Dataset()
        new_items = request.FILES['myfile']

        if not new_items.name.endswith('xlsx'):
            messages.info(request,'Wrong Format')
            return render(request,'upload.html')

        imported_data = dataset.load(new_items.read(),format='xlsx')
        for data in imported_data:
            value = AddItems(
                data[0],
                data[1],
                data[2],
                data[3],
                data[4],
                data[5]
            )
            value.save()
    return render(request, 'upload.html')
   
# ---------------Show Excel sheet Data-------------------
# Base url: 127.0.0.1:8000/show

def showdata(request):
    d={}
    if request.method=='GET':
        show = AddItems.objects.all()
        d={'show':show}
        return render(request,'showdata.html',context=d)


# ---------------Assignment 3--------------------------
def readdata(request):
    return render(request,'assignment3.html')

