from django.contrib import admin
from .models import *
from import_export.admin import ImportExportModelAdmin

admin.site.register(InsertItems)


# ----------- For assignment 2 (excel sheet)-----------
@admin.register(AddItems)
class AddItemsAdmin(admin.ModelAdmin):
    list_display=['Name']