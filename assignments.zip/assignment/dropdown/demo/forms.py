from django import forms
from .models import *

# class InsertItemsForm(forms.ModelFrom):
#     class Meta:
#         model = InsertItems
#         fields = "__all__"


class InsertItemsForm(forms.ModelForm):
    """Form definition for InsertItems."""

    class Meta:
        """Meta definition for InsertItemsform."""

        model = InsertItems
        fields = ('__all__')



