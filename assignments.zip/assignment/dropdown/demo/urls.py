from django.urls import path
from .views import *

urlpatterns =[
    path('',Home,name='home'),
    path('dropdown/',HomeView,name='dropdown'),
    path('upload/',excelsheet_upload,name='uploadexcel'),
    path('show/',showdata,name='show'),
    path('read/',readdata,name='read'),
]