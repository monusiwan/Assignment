from django.db import models

class InsertItems(models.Model):
    items = models.CharField(max_length=40)
    def __str__(self):
        return self.items


# -----------------Assignment 2 -------------------
class AddItems(models.Model):
    Name = models.CharField(max_length=100)
    Purchase_price = models.CharField(max_length=100)
    Category = models.CharField(max_length=100)
    MRP = models.CharField(max_length=30)
    Quantity = models.CharField(max_length=10)
     